package org.redhelp.adapter.items;

import android.support.v4.app.Fragment;

/**
 * Created by harshis on 7/26/14.
 */
public class ScreenShotItem {
    public Fragment fragment;
    public String name;
}
