package org.redhelp.adapter.items;

/**
 * Created by harshis on 6/9/14.
 */
public class PlacesAutoCompleteItem {
    public String description;
    public String reference;

    public PlacesAutoCompleteItem(String description, String reference) {
        this.description = description;
        this.reference = reference;
    }
}
