package org.redhelp.adapter.items;

/**
 * Created by harshis on 5/31/14.
 */
public class SlidingItem {
    public String tag;
    public int iconRes;
    public SlidingItem(String tag, int iconRes) {
        this.tag = tag;
        this.iconRes = iconRes;
    }
}