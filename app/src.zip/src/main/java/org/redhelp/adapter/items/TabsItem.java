package org.redhelp.adapter.items;

import java.io.Serializable;
import java.util.LinkedList;

/**
 * Created by harshis on 6/3/14.
 */
public class TabsItem implements Serializable {

    public LinkedList<TabItem> tabs;

    public TabsItem() {
        this.tabs = tabs;
    }
}
