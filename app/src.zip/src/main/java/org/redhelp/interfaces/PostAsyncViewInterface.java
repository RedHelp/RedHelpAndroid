package org.redhelp.interfaces;

/**
 * Created by harshis on 6/15/14.
 */
public interface PostAsyncViewInterface {

    public void showData();
}
