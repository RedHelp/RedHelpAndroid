package org.redhelp.data;

import android.widget.AutoCompleteTextView;

/**
 * Created by harshis on 8/6/14.
 */
public class PlacesSearchData {
    public String type;
    public String searchStr;
    public AutoCompleteTextView atvPlaces;
}