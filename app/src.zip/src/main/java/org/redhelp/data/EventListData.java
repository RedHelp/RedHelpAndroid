package org.redhelp.data;

import java.io.Serializable;

/**
 * Created by harshis on 9/1/14.
 */
public class EventListData implements Serializable{
    public Long e_id;
    public String venue;
    public String title;
    public String scheduled_date;
    public String distance;
}
