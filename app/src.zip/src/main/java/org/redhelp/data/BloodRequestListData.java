package org.redhelp.data;

import java.io.Serializable;

/**
 * Created by harshis on 9/1/14.
 */
public class BloodRequestListData implements Serializable {
    public Long b_r_id;
    public String title;
    public String bloodGroupsStr;
    public String venueStr;
    public String distance;
}
