package org.redhelp.util;

/**
 * Created by harshis on 9/5/14.
 */
public class ProfileHelper {
    public enum ProfileType{
        TEST, PROD
    }

    public static ProfileType profileType = ProfileType.PROD;
}
